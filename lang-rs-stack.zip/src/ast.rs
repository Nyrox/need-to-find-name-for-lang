

// We store constants in the largest possible format representable by the VM
#[derive(Clone, Debug)]
pub enum Value {
    Integer(i64),
    Decimal(f64),
}

#[derive(Copy, Clone, Debug)]
pub enum BinaryOp {
    Add,
    Sub,
    Mul,
    Div,
}

#[derive(Clone, Debug)]
pub enum Expr {
    BinaryOp(Box<Expr>, BinaryOp, Box<Expr>),
    Constant(Value)
}