pub mod grammar;
pub mod ast;
pub mod codegen;

fn main() {
	let _result = grammar::AstParser::new()
		.parse(r"(232 * 4 - 2) + 12 * 6 / 4").unwrap();
	
	println!("{:#?}", _result);

    codegen::gen(_result);
}